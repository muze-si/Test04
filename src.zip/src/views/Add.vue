
<template>
<div>
<div class="back">
    <p class="p_name">文件名</p>
    <input  class="filename" id="filename"  v-model="filename">
    <div class="alert-box-item">
		<div class="bigImg-div" @click="toGetImg">
			<img class="bigImg" :src=valueUrl v-if="valueUrl">
		</div>
	</div>
     <p class="upname"><span>上传人：</span>{{sname4}}</p>
     <p class="time"><span>上传时间：</span>{{sname5}}</p>
     <br>
     <button type="primary"  class="up" @click="up">UP</button>
</div>
</div>
</template>

<script>
/* eslint-disable */
    var aData = new Date();
	let inputElement = null
    import store from '@/store'
	export default {
        name: "Add",
        store,
		data() {
			return {
				valueUrl: '',
                sname4:localStorage.getItem('name'),
                sname5:aData,
                filename:''
			}
		},
		methods: {
			toGetImg() {
				if (inputElement === null) {
					inputElement = document.createElement('input')
					inputElement.setAttribute('type', 'file')
					inputElement.style.display = 'none'
                    if (window.addEventListener) {
						inputElement.addEventListener('change', this.uploadFile, false)
					} else {
						inputElement.attachEvent('onchange', this.uploadFile)
					}

					document.body.appendChild(inputElement)
				}
				inputElement.click()
			},
			uploadFile(el) {
				if (el && el.target && el.target.files && el.target.files.length > 0) {
					console.log(el)
					const files = el.target.files[0]
					const isLt2M = files.size / 1024 / 1024 < 2
					const size = files.size / 1024 / 1024
					console.log(size)
					if (!isLt2M) {
						this.$message.error('上传图片大小不能超过2MB!')
					} else if (files.type.indexOf('image') === -1) { 
						this.$message.error('请选择图片文件');
					} else {
						const that = this;
						const reader = new FileReader(); 
						reader.readAsDataURL(el.target.files[0]); 
						reader.onload = function() { 
							that.valueUrl = this.result;
							console.log(this.result);
						};
					}
				}
			},
           up(){
               store.commit('addItem', {
                   filename: this.filename,
                   valueUrl: this.result,
                   sname4:localStorage.getItem('name'),
                   sname5:aData,
                   })
                   this.$router.replace('./Homepage/List');
                   }
		},
		beforeDestroy() {
		    if (inputElement) {
		      if (window.addEventListener) {
		        inputElement.removeEventListener('change', this.onGetLocalFile, false)
		      } else {
		        inputElement.detachEvent('onchange', this.onGetLocalFile)
		      }
		      document.body.removeChild(inputElement)
		      inputElement = null
		      console.log('========inputelement destroy')
		    }
		  }
	}
</script>

<style>
.back{
    position:absolute;
    width:400px;
    height:600px;
    top:45%;
    left:50%;
    transform:translate(-50%,-50%);
    background: url("./img/background.png");
    box-shadow: 0 12px 16px 0  rgba(0,0,0,0.24), 0 17px 50px 0 #ccaef3;
   
}

.alert-box-item {
		overflow: hidden;
	}

	.bigImg-div {
		width: 200px;
		height: 200px;
		overflow: hidden;
		border: 5px solid white;
        margin-left: 100px;
        margin-top: 20px;
	}

	.bigImg {
		display: block;
		width: 200px;
		height: 200px;
	}

    .p_name{
        margin-top: 40px;
        margin-left: 170px;
        font-size: 20px;
    }
    .time{
        margin-left: 70px;
    }
    
    .upname{
        margin-left: 140px;
    }
.filename{
    margin-left: 100px;
    border: 3px solid white;
    width: 200px;
    margin-top: -10px;
}
    .up{
    width: 80px;
    background-color: #6a3ab8;
    border: none;
    color: #FAFAFA;
    padding: 5px;
    text-align: center;
    text-decoration: none;
    font-size: 13px;
    border-radius: 20px;
    outline:none;
    margin-bottom: 15px;
    margin-left: 160px;
}
.up:hover{
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
    cursor: pointer;
    background-color: rgb(99, 21, 243);
    transition: all 0.2s ease-in;
}

</style>

