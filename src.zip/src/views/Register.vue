<template>
  <div class="container">
    <div class="main">
      <div class="registerbox">
          <div class="registerbox-in">
          <div class="userbox">
           <img src="./img/user.png"/>
           <input  class="user" id="user"  v-model="name" placeholder="用户名">
           </div>
          <br>
          <div class="phonebox">
           <img src="./img/电话.png"/>
           <input  class="phone" id="phone"  v-model="phone" placeholder="电话">
           </div>
           <br>
          <div class="mailbox">
           <img src="./img/消息.png"/>
           <input  class="mail" id="mail"  v-model="mail" placeholder="邮箱">
           </div>
           <br>
          <div class="pwdbox">
            <img src="./img/passsword.png" />
            <input  class="pwd"  id="password" v-model="pwd" type="password"  placeholder="密码">
           </div>
           <br>
           <div class="pwdbox2">
            <img src="./img/passsword.png" />
            <input  class="pwd"  id="password_again" v-model="pwd_a" type="password"  placeholder="确认密码">
           </div>
           <br>
           <button type="primary"  class="register_btn" @click.prevent="register">Register</button>
           <br>
           <button type="primary"  class="login_btn" @click="login">Login</button>
     </div>
         <div class="background">
        </div>

      </div>
    </div>
  </div>
</template>

<script>
</script>

<style>
.registerbox{
    display:flex;
    position:absolute;
    width:800px;
    height:400px;
    top:40%;
    left:50%;
    transform:translate(-50%,-50%);
    box-shadow: 0 12px 16px 0  rgba(0,0,0,0.24), 0 17px 50px 0 #ccaef3;
}
.registerbox-in{
     background-color:#ccaef3;
     width:350px;
}
.userbox{
    margin-top:50px ;
    height:30px;
     width:230px;
     display: flex;
     margin-left:25px;
}

.phonebox{
    height:30px;
    width:225px;
    display: flex;
    margin-left:25px;
}

.mailbox{
    height:30px;
    width:225px;
    display: flex;
    margin-left:25px;
}

.pwdbox{
    height:30px;
    width:225px;
    display: flex;
    margin-left:25px;
}

.pwdbox2{
    height:30px;
    width:225px;
    display: flex;
    margin-left:25px;
}

.background{
    width:570px;
    background-size:cover;
    font-family:sans-serif;
    background: url("./img/background.png");
}

.uesr-text{
     position:left;
}
input{
    outline-style: none ;
    border: 0;
    border-bottom:1px solid #E9E9E9;
    background-color:transparent;
    height:20px;
     font-family:sans-serif;
    font-size:15px;
    color:white;
    font-weight:bold;
    margin-top: 5px;
}
input:focus{
    border-bottom:2px solid white;
    background-color:transparent;
     transition: all 0.2s ease-in;
     font-family:sans-serif;
    font-size:15px;
     color:white;
     font-weight:bold;

}
input:hover{
    border-bottom:2px solid white;
    background-color:transparent;
     transition: all 0.2s ease-in;
     font-family:sans-serif;
    font-size:15px;
     color:white;
     font-weight:bold;

}

.log-box{
    font-size:12px;
    display: flex;
    justify-content: space-between ;
    width:190px;
    margin-left:30px;
    color:white;
    margin-top:-5px;
    align-items: center;

}
.log-box-text{
    color:white;
    font-size:12px;
      text-decoration:underline;
    }

.login_btn{
    width: 80px;
    background-color: #6a3ab8;
    border: none;
    color: #FAFAFA;
    padding: 5px;
    text-align: center;
    text-decoration: none;
    font-size: 13px;
    border-radius: 20px;
    outline:none;

}
.login_btn:hover{
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
    cursor: pointer;
     background-color: rgb(99, 21, 243);
      transition: all 0.2s ease-in;
}

.warn{
    margin-top:60px;
    margin-left:-120px;
    margin-bottom: 5px;
     font-weight:bold;
    font-size:17px;
}

.register_btn{
    width: 80px;
    background-color: #6a3ab8;
    border: none;
    color: #FAFAFA;
    padding: 5px;
    text-align: center;
    text-decoration: none;
    font-size: 13px;
    border-radius: 20px;
    outline:none;
    margin-bottom: 10px;

}
.register_btn:hover{
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
    cursor: pointer;
    background-color: rgb(107, 34, 241);
    transition: all 0.2s ease-in;
}
</style>

<script>
const regex_phone = new RegExp('^[1]([3-9])[0-9]{9}$');
const regex_email = new RegExp('^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$');

export default {
    name:'Register',
    props: {
    msg: String
  },
  data(){
    return{
      name:"",
      pwd:"",
      pwd_a:"",
      phone:"",
      mail:""
      };
  },methods:{
    register()
    {
      if(localStorage['name']===this.name)
      {
        alert("该账号已注册");
      }
      else if(this.name==='')
      {
        alert("用户名不能为空");
      }
      else if(regex_phone.test(this.phone)==false)
      {
        alert("请输入正确的手机号");
      }
      else if(regex_email.test(this.mail)==false)
      {
        alert("请输入正确的邮箱");
      }
      else if(this.pwd!==this.pwd_a)
      {
        alert("请输入相同密码");
      }
      else{
        localStorage.setItem('name',this.name);
        localStorage.setItem('pwd',this.pwd);
        localStorage.setItem('mail',this.mail);
        localStorage.setItem('phone',this.phone);
        localStorage.setItem('s',"false");
        alert("注册成功");
        this.$router.replace('/Login');
      }
    },
    login()
    {
      this.$router.replace('/Login')
    },
  }
}
</script>
