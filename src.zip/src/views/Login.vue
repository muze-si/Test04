<template>
  <div class="container">
    <div class="main">
      <div class="loginbox">
          <div class="loginbox-in">
          <div class="userbox">
           <img src="./img/user.png"/>
           <input  class="user" id="user"  v-model="name" placeholder="用户名">
           </div>
          <br>
          <div class="pwdbox">
            <img src="./img/passsword.png" />
            <input  class="pwd"  id="password" v-model="pwd" type="password"  placeholder="密码">
           </div>
           <div class="keep">
                <input @click="save" id="yes" type="radio" value="0" >
                <label for="yes">保持登录状态</label>
              </div>
           <button type="primary"  class="login_btn" @click="login">Login</button>
           <br>
           <button type="primary"  class="register_btn" @click.prevent="register">Register</button>

     </div>
         <div class="background">
        </div>

      </div>
    </div>
  </div>
</template>

<script>
</script>

<style>
.loginbox{
    display:flex;
    position:absolute;
    width:800px;
    height:400px;
    top:40%;
    left:50%;
    transform:translate(-50%,-50%);
    box-shadow: 0 12px 16px 0  rgba(0,0,0,0.24), 0 17px 50px 0 #ccaef3;

}
.loginbox-in{
     background-color:#ccaef3;
     width:350px;
}
.userbox{
    margin-top:120px ;
    height:30px;
     width:230px;
     display: flex;
     margin-left:25px;
}

.pwdbox{
    height:30px;
    width:225px;
    display: flex;
    margin-left:25px;
}

.background{
    width:570px;
    background-size:cover;
    font-family:sans-serif;
    background: url("./img/background.png");
}

.uesr-text{
     position:left;
}

input{
    outline-style: none ;
    border: 0;
    border-bottom:1px solid #E9E9E9;
    background-color:transparent;
    height:20px;
     font-family:sans-serif;
    font-size:15px;
    color:white;
    font-weight:bold;
    margin-top: 5px;
}

input:focus{
    border-bottom:2px solid white;
    background-color:transparent;
     transition: all 0.2s ease-in;
     font-family:sans-serif;
    font-size:15px;
     color:white;
     font-weight:bold;

}

input:hover{
    border-bottom:2px solid white;
    background-color:transparent;
     transition: all 0.2s ease-in;
     font-family:sans-serif;
    font-size:15px;
     color:white;
     font-weight:bold;

}

.log-box{
    font-size:12px;
    display: flex;
    justify-content: space-between ;
    width:190px;
    margin-left:30px;
    color:white;
    margin-top:-5px;
    align-items: center;

}
.log-box-text{
    color:white;
    font-size:12px;
      text-decoration:underline;
    }

.login_btn{
    width: 80px;
    background-color: #6a3ab8;
    border: none;
    color: #FAFAFA;
    padding: 5px;
    text-align: center;
    text-decoration: none;
    font-size: 13px;
    border-radius: 20px;
    outline:none;
    margin-bottom: 15px;
    margin-top: 15px;
    margin-left: 110px;
}
.login_btn:hover{
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
    cursor: pointer;
     background-color: rgb(99, 21, 243);
      transition: all 0.2s ease-in;
}

.warn{
    margin-top:60px;
    margin-left:-120px;
    margin-bottom: 5px;
     font-weight:bold;
    font-size:17px;
}

.keep{
  margin-left: 20px;
  color: white;
  font-size: 15px;
}

.keep input{
  width: 15px;
  height: 15px;
  margin-top: 8px;
  margin-left: 12px;
  margin-right: 10px;
}

.register_btn{
    width: 80px;
    background-color: #6a3ab8;
    border: none;
    color: #FAFAFA;
    padding: 5px;
    text-align: center;
    text-decoration: none;
    font-size: 13px;
    border-radius: 20px;
    outline:none;
    margin-bottom: 10px;
    margin-left: 110px;

}
.register_btn:hover{
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
    cursor: pointer;
    background-color: rgb(107, 34, 241);
    transition: all 0.2s ease-in;
}
</style>

<script>
export default {
  data(){
    return{
      name:"",
      pwd:"",
      st:"false",
    };
  },
  methods:{
    login:function()
    {
      if(this.name===localStorage['name'] && this.pwd===localStorage['pwd'])
       {
         this.$router.replace('/Homepage');
       }
       else if(this.name==='')
       {
         alert('用户名不为空');
       }
       else if(this.pwd==='')
       {
         alert('密码不为空');
       }
      else{
        alert('账号不存在，请注册后登录');
        }
    },
    register()
    {
      this.$router.replace('/Register')
    },
     save:function(){
      this.st="true";
      localStorage.setItem('s',this.st);
      console.log(localStorage.s);
    }
  }
};
</script>
