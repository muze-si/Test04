<template>
<div class="roll">
    <ul class="L">
        <li class="list" v-for="(item,index) in pageLists"
        :key="index">
         {{item.filename}}   {{item.sname4}}<br>
         {{item.sname5}}
        </li>
       </ul>
       </div>
</template>

<script>
/* eslint-disable */
import store from '@/store'
export default{
    name: "List",
    store,
    computed: {
        pageLists () {
           return store.state.lists 
        }
    }
}
</script>

<style>
.L{
    margin-top: 40px;
    }
.list{
   width: 450px;
   height: 45px;
   margin-top: 5px;
   margin-left: -20px;
   border-radius: 10px;
   border: 3px solid rgb(78, 6, 114);
   padding-left: 5px;
   }

.roll{
     overflow-y:auto; 
     height:400px
}

</style>