<template>
<div class="container">
    <div class="main">
               <div class="background_user">
                   <div class="user_image1">
                       <img src="./img/user.png"/>
               </div>
               <p class="content"><span class="content">用户名：</span>{{sname1}}</p>
               <p class="content"><span class="content">电话：</span>{{sname2}}</p>
               <p class="content"><span class="content">Email：</span>{{sname3}}</p>
               <button class="add" @click.prevent="add">上传图片</button>
          </div>
          </div>
       </div>
</template>

<script>
/* eslint-disable */
export default {
    name:'User',
    data(){
      return{
        sname1:localStorage.getItem('name'),
        sname2:localStorage.getItem('phone'),
        sname3:localStorage.getItem('mail'),
        isAuth:"",
      };
    },
    methods:{
      add:function()
      {
        this.$router.replace('/Add');
      }
    }
}
</script>

<style>
.background_user{
    width:497px;
    height: 369px;
    background-size:cover;
    font-family:sans-serif;
    background: url("./img/background.png");
    margin-left: 0px;
    padding-top: 1px;
    margin-top:30px;
    }
    

.user_image1{
  width:90px; 
  height:90px; 
  border-radius:50%; 
  overflow:hidden;
  border: 6px solid black;
  margin-left: 200px;
  margin-top: 30px;
  }

.user_image1 > img{
  width: 100%;
  height: 100%;
  }

 .content{
  font-size: 15px;
  margin-top: 20px;
  text-align: left;
  margin-left: 90px;
  color: black;
  font-weight:bolder;
  }

.add{
    width: 80px;
    background-color: #6a3ab8;
    border: none;
    color: #FAFAFA;
    padding: 5px;
    text-align: center;
    text-decoration: none;
    font-size: 13px;
    border-radius: 20px;
    outline:none;
    margin-bottom: 15px;
    margin-left: 220px;
}
.add:hover{
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
    cursor: pointer;
    background-color: rgb(99, 21, 243);
    transition: all 0.2s ease-in;
}

</style>
