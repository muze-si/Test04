<template>
<div class="container">
    <div class="main">
      <div class="homebox">
          <div class="homebox-in">
            <div class="user_image">
              <img src="./img/我的.png"/>
               </div>
               <p><span></span>{{sname}}</p><br>
               <button class="logout" @click.prevent="logout">退出登入</button>
          </div>
         <div class="background_home">
           <div>
             <router-view/>
             <ul class="footer">
               <li class="icons"><router-link :to="{name: 'List'}">文件目录</router-link></li>
               <li class="icons"><router-link :to="{name: 'User'}">个人中心</router-link></li>
               </ul>
               </div>
        </div>
       </div>
    </div>
  </div>

</template>

<script>
/* eslint-disable */
export default {
    name:'Home',
    data(){
      return{
        sname:localStorage.getItem('name'),
        isAuth:"",
      };
    },
    methods:{
      logout:function()
      {
        this.isAuth="false";
        localStorage.setItem('s',this.isAuth);
        this.$router.replace('/Login');
      }
    }
}
</script>

<style>
.homebox{
    display:flex;
    position:absolute;
    width:800px;
    height:400px;
    top:40%;
    left:50%;
    transform:translate(-50%,-50%);
    box-shadow: 0 12px 16px 0  rgba(0,0,0,0.24), 0 17px 50px 0 #ccaef3;

}
.homebox-in{
     background-color:#ccaef3;
     width:350px;
}
.background_home{
    width:570px;
    background-size:cover;
    font-family:sans-serif;
    }

.user_image{
  width:90px; 
  height:90px; 
  border-radius:50%; 
  overflow:hidden;
  border: 6px solid #fff;
  margin-left: 100px;
  margin-top: 80px;
  }

.user_image > img{
  width: 100%;
  height: 100%;
  }

  p{
  font-size: 15px;
  margin-top: 15px;
  text-align: left;
  margin-left: 115px;
  color: #fff;
  font-weight:bolder;
  }

.logout{
    width: 80px;
    background-color: #6a3ab8;
    border: none;
    color: #FAFAFA;
    padding: 5px;
    text-align: center;
    text-decoration: none;
    font-size: 13px;
    border-radius: 20px;
    outline:none;
    margin-bottom: 15px;
    margin-left: 110px;
}
.logout:hover{
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
    cursor: pointer;
    background-color: rgb(99, 21, 243);
    transition: all 0.2s ease-in;
}

li{
  list-style: none;
}

.footer{
  position: fixed;
  width: 496px;
  height: 30px;
  line-height: 30px;
  right: 0;
  top: 0;
  display: flex;
  flex-flow: row nowrap;
  justify-content:space-around;
  padding: 0;
  margin: 0;
  text-decoration: none;
}

.icons{
  text-align: center;
  flex: 1;
  border-bottom: 3px solid rgb(99, 21, 243);
  color: rgb(99, 21, 243);
  text-decoration-line: none;
}

.icons:hover{
  background-color: #ccaef3;
  text-decoration-line: none;
}
</style>
