import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from '../views/Login.vue'
import Home from '../views/Homepage.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    redirect: {
      name: 'Home'
    }
  },
  {
    path: '/Login',
    name: 'Login',
    component: Login
  },
  {
    path: '/Homepage',
    name: 'Home',
    component: Home,
    children: [
      {
        path: 'List',
        name: 'List',
        component: () =>
          import('../views/List.vue')
      },
      {
        path: 'User',
        name: 'User',
        component: () =>
          import('../views/User.vue')
      }
    ]
  },
  {
    path: '/Register',
    name: 'Register',
    component: () =>
      import('../views/Register.vue')
  },
  {
    path: '/Add',
    name: 'Add',
    component: () =>
      import('../views/Add.vue')
  }
]

const router = new VueRouter({
  mode: 'history',
  routes
})
/* eslint-disable */
router.beforeEach((to, from, next) => {
  if (to.path === '/Login') {
    next()
    console.log(localStorage.s)
  } else if (to.path === '/Register') {
    next()
  } else {
    if (from.path === '/Login') {
      next()
    } else {
      if (localStorage.s === 'true') {
        next()
		    console.log(localStorage['s'])
      } else {
	      next('/Login');
	      console.log("需要登录")
	    }
    }
  }
})
export default router
